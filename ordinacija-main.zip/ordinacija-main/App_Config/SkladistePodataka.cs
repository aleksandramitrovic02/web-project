﻿using Newtonsoft.Json;
using System.IO;
using System.Web.Hosting;

namespace Ordinacija.App_Config
{
    public class SkladistePodataka
    {
        public static JsonTabele Database { get; set; } = new JsonTabele();

        public static void UcitavanjePodataka()
        {
            try
            {
                string filePath = Path.Combine(HostingEnvironment.MapPath(@"~/App_Data/"), "db.json");
                if (File.Exists(filePath))
                {
                    using (StreamReader sr = new StreamReader(filePath))
                    {
                        Database = JsonConvert.DeserializeObject<JsonTabele>(sr.ReadToEnd());
                    }
                }
            }
            catch { }
        }

        public static void AzuriranjePodataka()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(Path.Combine(HostingEnvironment.MapPath(@"~/App_Data/"), "db.json")))
                {
                    string json = JsonConvert.SerializeObject(Database, Formatting.Indented);
                    sw.Write(json);
                }
            }
            catch { }
        }
    }
}