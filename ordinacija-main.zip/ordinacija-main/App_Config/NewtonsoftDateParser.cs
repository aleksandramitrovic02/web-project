﻿using Newtonsoft.Json.Converters;
using System;
using System.Globalization;

namespace Newtonsoft.Json.Utils
{
    /// <summary>
    /// Provides custom serialization type for Newtonsoft.Json and BSON converters.
    /// This converter ensures that DateTime values are serialized and deserialized using a specified date format.
    /// 
    /// <para><b>Usage with Newtonsoft.Json:</b></para>
    /// <code>
    /// <![CDATA[
    /// using Newtonsoft.Json;
    /// using Ordinacija.Models;
    /// 
    /// var settings = new JsonSerializerSettings
    /// {
    ///     ContractResolver = new CustomContractResolver(),
    ///     Formatting = Formatting.Indented
    /// };
    /// 
    /// var pacijent = new Pacijent
    /// {
    ///     DatumRodjenja = new DateTime(1980, 1, 1)
    /// };
    /// 
    /// string json = JsonConvert.SerializeObject(pacijent, settings);
    /// Pacijent deserializedPacijent = JsonConvert.DeserializeObject<Pacijent>(json, settings);
    /// ]]>
    /// </code>
    /// </summary>
    public class NewtonsoftDateParser : DateTimeConverterBase
    {
        private readonly string convertion;

        public NewtonsoftDateParser(string dateFormat)
        {
            convertion = dateFormat;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(((DateTime)value).ToString(convertion, CultureInfo.InvariantCulture));
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.Value == null)
                return null;

            return DateTime.ParseExact(reader.Value.ToString(), convertion, CultureInfo.InvariantCulture);
        }
    }
}