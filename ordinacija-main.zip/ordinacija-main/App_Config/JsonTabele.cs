﻿using Ordinacija.Models;
using System.Collections.Generic;

namespace Ordinacija.App_Config
{
    public class JsonTabele
    {
        public List<Administrator> Administratori { get; set; }
        public List<Lekar> Lekari { get; set; }
        public List<Pacijent> Pacijenti { get; set; }
        public List<Termin> Termini { get; set; }
        public List<ZdravstveniKarton> ZdravstveniKartoni { get; set; }

        public JsonTabele()
        {
            Administratori = new List<Administrator>();
            Lekari = new List<Lekar>();
            Pacijenti = new List<Pacijent>();
            Termini = new List<Termin>();
            ZdravstveniKartoni = new List<ZdravstveniKarton>();
        }
    }
}