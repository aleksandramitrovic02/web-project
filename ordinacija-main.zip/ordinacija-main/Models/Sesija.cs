﻿namespace Ordinacija.Models
{
    public enum Uloga { ADMIN, PACIJENT, LEKAR };

    public class Sesija
    {
        public string KorisnickoIme { get; set; }

        public Uloga Uloga { get; set; }
    }

    public class PrijavaDTO
    {
        public string KorisnickoIme { get; set; }

        public string Lozinka { get; set; }
    }
}