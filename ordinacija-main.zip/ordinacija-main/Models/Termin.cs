﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace Ordinacija.Models
{
    public enum StatusTermina { SLOBODAN, ZAUZET };

    public class Termin
    {
        public string TerminID { get; set; }

        public string Lekar { get; set; }

        [JsonIgnore]
        public Lekar LekarPodaci {  get; set; }

        public string Pacijent { get; set; }

        [JsonIgnore]
        public Pacijent PacijentPodaci { get; set; }

        public StatusTermina StatusTermina { get; set; }

        [Required]
        public DateTime DatumTermina { get; set; }

        public string OpisTerapije { get; set; }

        public Termin() { }

        public Termin(string terminID, string lekar, string pacijent, StatusTermina statusTermina, DateTime datumTermina, string opisTerapije)
        {
            TerminID = terminID;
            Lekar = lekar;
            Pacijent = pacijent;
            StatusTermina = statusTermina;
            DatumTermina = datumTermina;
            OpisTerapije = opisTerapije;
        }
    }
}