﻿using Newtonsoft.Json;
using Newtonsoft.Json.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Ordinacija.Models
{
    public class Lekar
    {
        public string KorisnickoIme { get; set; }

        public string Sifra { get; set; }

        public string Ime { get; set; }

        public string Prezime { get; set; }

        [Required]
        [JsonConverter(typeof(NewtonsoftDateParser), "dd/MM/yyyy")]
        public DateTime DatumRodjenja { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public List<string> Termini { get; set; } = new List<string>();

        public Lekar() { }

        public Lekar(string korisnickoIme, string sifra, string ime, string prezime, DateTime datumRodjenja, string email, List<string> termini)
        {
            KorisnickoIme = korisnickoIme;
            Sifra = sifra;
            Ime = ime;
            Prezime = prezime;
            DatumRodjenja = datumRodjenja;
            Email = email;
            Termini = termini;
        }
    }
}