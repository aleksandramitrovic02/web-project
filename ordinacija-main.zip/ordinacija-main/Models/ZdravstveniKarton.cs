﻿using System.Collections.Generic;

namespace Ordinacija.Models
{
    public class ZdravstveniKarton
    {
        public string Pacijent { get; set; }

        public List<string> Termini { get; set; } = new List<string>();

        public ZdravstveniKarton() { }

        public ZdravstveniKarton(string pacijent, List<string> termini)
        {
            Pacijent = pacijent;
            Termini = termini;
        }
    }
}