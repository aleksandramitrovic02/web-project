﻿using Ordinacija.App_Config;
using Ordinacija.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Ordinacija.Controllers
{
    public class AdministratorController : Controller
    {
        // Prikaz svih pacijenata 
        public ActionResult Index(string sortOrder, string searchJMBG, string searchIme, string searchPrezime, string searchDatumRodjenja, string searchEmail)
        {
            if (Autorizacija() == false)
                return RedirectToAction("Index", "Login");

            ViewBag.CurrentSort = sortOrder;

            var pacijenti = from p in SkladistePodataka.Database.Pacijenti
                            select p;

            if (!string.IsNullOrEmpty(searchJMBG))
            {
                pacijenti = pacijenti.Where(p => p.JMBG.Contains(searchJMBG));
            }
            if (!string.IsNullOrEmpty(searchIme))
            {
                pacijenti = pacijenti.Where(p => p.Ime.Contains(searchIme));
            }
            if (!string.IsNullOrEmpty(searchPrezime))
            {
                pacijenti = pacijenti.Where(p => p.Prezime.Contains(searchPrezime));
            }
            if (!string.IsNullOrEmpty(searchDatumRodjenja) && DateTime.TryParse(searchDatumRodjenja, out DateTime searchDate))
            {
                pacijenti = pacijenti.Where(p => p.DatumRodjenja == searchDate);
            }
            if (!string.IsNullOrEmpty(searchEmail))
            {
                pacijenti = pacijenti.Where(p => p.Email.Contains(searchEmail));
            }

            switch (sortOrder)
            {
                case "JMBG_desc":
                    pacijenti = pacijenti.OrderByDescending(p => p.JMBG);
                    break;
                case "Ime":
                    pacijenti = pacijenti.OrderBy(p => p.Ime);
                    break;
                case "Ime_desc":
                    pacijenti = pacijenti.OrderByDescending(p => p.Ime);
                    break;
                case "Prezime":
                    pacijenti = pacijenti.OrderBy(p => p.Prezime);
                    break;
                case "Prezime_desc":
                    pacijenti = pacijenti.OrderByDescending(p => p.Prezime);
                    break;
                case "DatumRodjenja":
                    pacijenti = pacijenti.OrderBy(p => p.DatumRodjenja);
                    break;
                case "DatumRodjenja_desc":
                    pacijenti = pacijenti.OrderByDescending(p => p.DatumRodjenja);
                    break;
                case "Email":
                    pacijenti = pacijenti.OrderBy(p => p.Email);
                    break;
                case "Email_desc":
                    pacijenti = pacijenti.OrderByDescending(p => p.Email);
                    break;
                default:
                    pacijenti = pacijenti.OrderBy(p => p.JMBG);
                    break;
            }

            return View(pacijenti.ToList());
        }

        public ActionResult AddPage()
        {
            if (Autorizacija() == true)
                return View();

            return RedirectToAction("Index", "Login");
        }

        [HttpGet]
        public ActionResult EditPage(string korisnickoIme)
        {
            if (Autorizacija() == true && string.IsNullOrEmpty(korisnickoIme) == false)
            {
                Pacijent p = SkladistePodataka.Database.Pacijenti.FirstOrDefault(x => x.KorisnickoIme == korisnickoIme);
                if (p == null)
                {
                    Session["admin_greska"] = "Pacijent je obrisan!";
                    return RedirectToAction("Index");
                }

                return View(p);
            }

            return RedirectToAction("Index", "Login");
        }

        [HttpPost]
        public ActionResult Add(Pacijent pacijent)
        {
            try
            {
                Session["admin_greska"] = null;
                List<Pacijent> pacijenti = SkladistePodataka.Database.Pacijenti;
                List<ZdravstveniKarton> kartoni = SkladistePodataka.Database.ZdravstveniKartoni;

                if (ModelState.IsValid == true && Autorizacija() == true)
                {
                    // korisničko ime, adresa elektronske pošte i JMBG jedinstveni
                    if (pacijent.KorisnickoIme == "admin" || pacijent.KorisnickoIme == "admin1" || pacijent.KorisnickoIme == "draleks" ||
                    pacijent.KorisnickoIme == "drneven" || pacijent.KorisnickoIme == "drol")
                    {
                        Session["admin_greska"] = "Nije dozvoljena upotreba predefinisanih korisnickih imena!";
                        return RedirectToAction("Index");
                    }

                    if (pacijenti.Exists(x => x.KorisnickoIme == pacijent.KorisnickoIme))
                    {
                        Session["admin_greska"] = "Korisnicko ime je zauzeto!";
                        return RedirectToAction("Index");
                    }

                    if (pacijenti.Exists(x => x.Email == pacijent.Email))
                    {
                        Session["admin_greska"] = "Elektronska posta je zauzeta!";
                        return RedirectToAction("Index");
                    }

                    if (pacijenti.Exists(x => x.JMBG == pacijent.JMBG))
                    {
                        Session["admin_greska"] = "Maticni broj (JMBG) ime je zauzet!";
                        return RedirectToAction("Index");
                    }

                    pacijenti.Add(pacijent);
                    kartoni.Add(new ZdravstveniKarton(pacijent.KorisnickoIme, new List<string>()));
                    SkladistePodataka.AzuriranjePodataka();

                    return RedirectToAction("Index");
                }
                else
                {
                    Session["admin_greska"] = "Nije moguce dodati pacijenta sa podacima koji nisu validni!";
                    return RedirectToAction("Index");
                }

            }
            catch
            {
                Session["admin_greska"] = "Nije moguce dodati pacijenta!";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public ActionResult Edit(Pacijent pacijent)
        {
            try
            {
                Session["admin_greska"] = null;
                List<Pacijent> pacijenti = SkladistePodataka.Database.Pacijenti;

                if (ModelState.IsValid == true && Autorizacija() == true)
                {
                    Pacijent pronadjen = SkladistePodataka.Database.Pacijenti.FirstOrDefault(p => p.KorisnickoIme == pacijent.KorisnickoIme);
                    if (pronadjen != null)
                    {
                        // ako je unet novi email proveriti da li je on slobodan
                        if (pronadjen.Email != pacijent.Email && pacijenti.Exists(x => x.KorisnickoIme != pacijent.KorisnickoIme && x.Email == pacijent.Email))
                        {
                            Session["admin_greska"] = "Email adresa je zauzeta od strane drugog pacijenta!";
                            return RedirectToAction("Index");
                        }

                        pronadjen.Ime = pacijent.Ime;
                        pronadjen.Prezime = pacijent.Prezime;
                        pronadjen.DatumRodjenja = pacijent.DatumRodjenja;
                        pronadjen.Email = pacijent.Email;
                        pronadjen.Sifra = pacijent.Sifra;

                        SkladistePodataka.AzuriranjePodataka();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        Session["admin_greska"] = "Pacijent je obrisan. Izmena nije moguca!";
                        return RedirectToAction("Index");
                    }
                }
                else
                {
                    Session["admin_greska"] = "Nije moguce izmeniti pacijenta sa podacima koji nisu validni!";
                    return RedirectToAction("Index");
                }
            }
            catch
            {
                Session["admin_greska"] = "Nije moguce izmeniti pacijenta!";
                return RedirectToAction("Index");
            }
        }

        public ActionResult Delete(string korisnickoIme)
        {
            try
            {
                if (Autorizacija() == true && string.IsNullOrEmpty(korisnickoIme) == false)
                {
                    List<Pacijent> pacijenti = SkladistePodataka.Database.Pacijenti;
                    List<ZdravstveniKarton> kartoni = SkladistePodataka.Database.ZdravstveniKartoni;
                    List<Termin> termini = SkladistePodataka.Database.Termini;

                    Pacijent pacijent = SkladistePodataka.Database.Pacijenti.FirstOrDefault(x => x.KorisnickoIme == korisnickoIme);
                    if (pacijent == null)
                    {
                        Session["admin_greska"] = "Pacijent je vec obrisan!";
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        pacijenti.Remove(pacijent);
                        kartoni.RemoveAll(x => x.Pacijent == korisnickoIme);
                        termini.RemoveAll(x => x.Pacijent == korisnickoIme);
                        SkladistePodataka.AzuriranjePodataka();

                        return RedirectToAction("Index");
                    };
                }
                else
                {
                    Session["admin_greska"] = "Nije moguce obrisati pacijenta sa podacima koji nisu validni!";
                    return RedirectToAction("Index");
                }
            }
            catch
            {
                Session["admin_greska"] = "Nije moguce obrisati pacijenta!";
                return RedirectToAction("Index");
            }
        }

        public bool Autorizacija()
        {
            return Session["korisnik"] is Sesija sesija && sesija.Uloga == Uloga.ADMIN;
        }
    }
}