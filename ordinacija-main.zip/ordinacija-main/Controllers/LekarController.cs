﻿using Microsoft.Ajax.Utilities;
using Ordinacija.App_Config;
using Ordinacija.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Ordinacija.Controllers
{
    public class LekarController : Controller
    {
        // Prikaz svih terapija koje pripadaju lekaru
        public ActionResult Index(string sortOrder, string searchJMBG, string searchIme, string searchPrezime, string searchDatum, string statusFilter)
        {
            (bool autorizovan, string lekar) = Autorizacija();

            if (!autorizovan)
                return RedirectToAction("Index", "Login");

            IEnumerable<Termin> termini = SkladistePodataka.Database.Termini.Where(x => x.Lekar == lekar);
            List<Pacijent> pacijenti = SkladistePodataka.Database.Pacijenti;

            // Povezivanje pacijenta sa terminom
            termini.ForEach(x =>
            {
                if (string.IsNullOrEmpty(x.Pacijent))
                    x.PacijentPodaci = new Pacijent("/", "/", "/", "/", "/", DateTime.Now, "/", new List<string>());
                else
                    x.PacijentPodaci = pacijenti.FirstOrDefault(p => p.KorisnickoIme == x.Pacijent);
            });

            if (!string.IsNullOrEmpty(searchJMBG))
                termini = termini.Where(t => t.PacijentPodaci.JMBG.Contains(searchJMBG));

            if (!string.IsNullOrEmpty(searchIme))
                termini = termini.Where(t => t.PacijentPodaci.Ime.Contains(searchIme));

            if (!string.IsNullOrEmpty(searchPrezime))
                termini = termini.Where(t => t.PacijentPodaci.Prezime.Contains(searchPrezime));

            if (!string.IsNullOrEmpty(searchDatum) && (DateTime.TryParse(searchDatum, out DateTime datumTermina)))
                termini = termini.Where(t => t.DatumTermina == datumTermina);

            if (!string.IsNullOrEmpty(statusFilter))
            {
                var statusEnum = (StatusTermina)Enum.Parse(typeof(StatusTermina), statusFilter);
                termini = termini.Where(t => t.StatusTermina == statusEnum);
            }

            ViewBag.CurrentFilterJMBG = searchJMBG;
            ViewBag.CurrentFilterIme = searchIme;
            ViewBag.CurrentFilterPrezime = searchPrezime;
            ViewBag.CurrentFilterDatum = searchDatum;
            ViewBag.StatusFilter = statusFilter;

            ViewBag.JmbgSortParm = sortOrder == "JMBG" ? "jmbg_desc" : "JMBG";
            ViewBag.ImeSortParm = sortOrder == "Ime" ? "ime_desc" : "Ime";
            ViewBag.PrezimeSortParm = sortOrder == "Prezime" ? "prezime_desc" : "Prezime";
            ViewBag.StatusSortParm = sortOrder == "Status" ? "status_desc" : "Status";
            ViewBag.DatumSortParm = sortOrder == "Datum" ? "datum_desc" : "Datum";

            switch (sortOrder)
            {
                case "JMBG":
                    termini = termini.OrderBy(t => t.PacijentPodaci.JMBG);
                    break;
                case "jmbg_desc":
                    termini = termini.OrderByDescending(t => t.PacijentPodaci.JMBG);
                    break;
                case "Ime":
                    termini = termini.OrderBy(t => t.PacijentPodaci.Ime);
                    break;
                case "ime_desc":
                    termini = termini.OrderByDescending(t => t.PacijentPodaci.Ime);
                    break;
                case "Prezime":
                    termini = termini.OrderBy(t => t.PacijentPodaci.Prezime);
                    break;
                case "prezime_desc":
                    termini = termini.OrderByDescending(t => t.PacijentPodaci.Prezime);
                    break;
                case "Status":
                    termini = termini.OrderBy(t => t.StatusTermina);
                    break;
                case "status_desc":
                    termini = termini.OrderByDescending(t => t.StatusTermina);
                    break;
                case "Datum":
                    termini = termini.OrderBy(t => t.DatumTermina);
                    break;
                case "datum_desc":
                    termini = termini.OrderByDescending(t => t.DatumTermina);
                    break;
                default:
                    termini = termini.OrderBy(t => t.DatumTermina);
                    break;
            }

            return View(termini.ToList());
        }

        public ActionResult AddPage()
        {
            if (Autorizacija().Item1 == true)
                return View();

            return RedirectToAction("Index", "Login");
        }

        public ActionResult TerapijePage()
        {
            (bool autorizovan, string lekar) = Autorizacija();

            if (!autorizovan)
                return RedirectToAction("Index", "Login");

            IEnumerable<Termin> termini = SkladistePodataka.Database.Termini.Where(x => x.Lekar == lekar && x.StatusTermina == StatusTermina.ZAUZET);

            // Povezivanje pacijenta sa terminom
            termini.ForEach(x =>
            {
                if (string.IsNullOrEmpty(x.Pacijent))
                    x.PacijentPodaci = new Pacijent("/", "/", "/", "/", "/", DateTime.Now, "/", new List<string>());
                else
                    x.PacijentPodaci = SkladistePodataka.Database.Pacijenti.FirstOrDefault(p => p.KorisnickoIme == x.Pacijent);
            });

            return View(termini);
        }

        [HttpPost]
        public ActionResult Add(Termin termin)
        {
            try
            {
                Session["lekar_greska"] = null;
                (bool autorizovan, string lekar) = Autorizacija();

                if (!autorizovan || ModelState.IsValid == false)
                    return RedirectToAction("Index", "Login");

                Lekar trenutni = SkladistePodataka.Database.Lekari.FirstOrDefault(x => x.KorisnickoIme == lekar);

                if (trenutni == null)
                {
                    Session["lekar_greska"] = "Lekar vise nije validan!";
                    return RedirectToAction("Index", "Login");
                }

                termin.TerminID = Guid.NewGuid().ToString().Replace("-", "");
                termin.Lekar = lekar;
                SkladistePodataka.Database.Termini.Add(termin);
                trenutni.Termini.Add(termin.TerminID);
                SkladistePodataka.AzuriranjePodataka();

                return RedirectToAction("Index");
            }
            catch
            {
                Session["lekar_greska"] = "Nije moguce dodati termin!";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public ActionResult AddTherapy(string terminId, string terapija)
        {
            try
            {
                Session["lekar_greska"] = null;
                (bool autorizovan, string lekar) = Autorizacija();

                if (!autorizovan || ModelState.IsValid == false || string.IsNullOrEmpty(terminId) || string.IsNullOrEmpty(terapija))
                    return RedirectToAction("Index", "Login");

                Termin termin = SkladistePodataka.Database.Termini.FirstOrDefault(x => x.TerminID == terminId && string.IsNullOrEmpty(x.OpisTerapije) == true);

                if (termin == null)
                {
                    Session["lekar_greska"] = "Termin vise nije validan!";
                    return RedirectToAction("Index", "Login");
                }

                termin.OpisTerapije = terapija;
                SkladistePodataka.AzuriranjePodataka();
                return RedirectToAction("TerapijePage");
            }
            catch
            {
                Session["lekar_greska"] = "Nije moguce dodati terapiju!";
                return RedirectToAction("Index");
            }
        }

        public (bool, string) Autorizacija()
        {
            if (Session["korisnik"] is Sesija sesija && sesija.Uloga == Uloga.LEKAR)
                return (true, sesija.KorisnickoIme);
            else
                return (false, null);
        }
    }
}
