﻿using Ordinacija.App_Config;
using Ordinacija.Models;
using System.Web.Mvc;

namespace Ordinacija.Controllers
{
    public class LoginController : Controller
    {
        // Stranica - Prijava
        public ActionResult Index()
        {
            return Autorizacija();
        }

        [HttpPost]
        public ActionResult Prijava(PrijavaDTO podaci)
        {
            try
            {
                if (podaci == null || string.IsNullOrEmpty(podaci.KorisnickoIme) || string.IsNullOrEmpty(podaci.Lozinka))
                {
                    Session["prijava_greska"] = "Proverite unete podatke!";
                    return RedirectToAction("Index");
                }
                else
                {
                    Session["prijava_greska"] = null;

                    if (SkladistePodataka.Database.Administratori.Exists(x => x.KorisnickoIme == podaci.KorisnickoIme && x.Sifra == podaci.Lozinka))
                    {
                        Session["korisnik"] = new Sesija() { KorisnickoIme = podaci.KorisnickoIme, Uloga = Uloga.ADMIN };
                        return RedirectToAction("Index", "Administrator");
                    }
                    else if (SkladistePodataka.Database.Lekari.Exists(x => x.KorisnickoIme == podaci.KorisnickoIme && x.Sifra == podaci.Lozinka))
                    {
                        Session["korisnik"] = new Sesija() { KorisnickoIme = podaci.KorisnickoIme, Uloga = Uloga.LEKAR };
                        return RedirectToAction("Index", "Lekar");
                    }
                    else if (SkladistePodataka.Database.Pacijenti.Exists(x => x.KorisnickoIme == podaci.KorisnickoIme && x.Sifra == podaci.Lozinka))
                    {
                        Session["korisnik"] = new Sesija() { KorisnickoIme = podaci.KorisnickoIme, Uloga = Uloga.PACIJENT };
                        return RedirectToAction("Index", "Pacijent");
                    }
                    else
                    {
                        Session["korisnik"] = null;
                        Session["prijava_greska"] = "Korisnik ne postoji!";
                        return RedirectToAction("Index");
                    }
                }
            }
            catch
            {
                Session["prijava_greska"] = "Prijava nije moguca!";
                return RedirectToAction("Index");
            }
        }

        public ActionResult Autorizacija()
        {
            if (Session["korisnik"] is Sesija sesija)
            {
                if (sesija.Uloga == Uloga.ADMIN)
                    return RedirectToAction("Index", "Administrator");
                else if (sesija.Uloga == Uloga.LEKAR)
                    return RedirectToAction("Index", "Lekar");
                else if (sesija.Uloga == Uloga.PACIJENT)
                    return RedirectToAction("Index", "Pacijent");
                else
                    return View("Index");
            }
            else
                return View("Index");
        }

        public ActionResult Odjava()
        {
            Session["korisnik"] = null; Session.Clear();
            return RedirectToAction("Index");
        }
    }
}