﻿using Microsoft.Ajax.Utilities;
using Ordinacija.App_Config;
using Ordinacija.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ordinacija.Controllers
{
    public class PacijentController : Controller
    {
        // Prikaz svih slobodnih termina za pacijenta
        public ActionResult Index(string sortOrder, string searchLekar, string searchDatum, string searchVreme)
        {
            (bool autorizovan, string pacijent) = Autorizacija();

            if (!autorizovan)
                return RedirectToAction("Index", "Login");

            IEnumerable<Termin> termini = SkladistePodataka.Database.Termini.Where(x => x.StatusTermina == StatusTermina.SLOBODAN);
            List<Lekar> lekari = SkladistePodataka.Database.Lekari;

            // Povezivanje lekara sa terminom
            termini.ForEach(x =>
            {
                if (string.IsNullOrEmpty(x.Lekar))
                    x.LekarPodaci = new Lekar("/", "/", "/", "/", DateTime.Now, "/", new List<string>());
                else
                    x.LekarPodaci = lekari.FirstOrDefault(l => l.KorisnickoIme == x.Lekar);
            });

            if (!string.IsNullOrEmpty(searchLekar))
                termini = termini.Where(t => t.LekarPodaci.Ime.Contains(searchLekar) || t.LekarPodaci.Prezime.Contains(searchLekar));

            if (!string.IsNullOrEmpty(searchDatum) && DateTime.TryParse(searchDatum, out DateTime datumTermina))
                termini = termini.Where(t => t.DatumTermina.Date == datumTermina.Date);

            if (!string.IsNullOrEmpty(searchVreme) && TimeSpan.TryParse(searchVreme, out TimeSpan vremeTermina))
                termini = termini.Where(t => t.DatumTermina.TimeOfDay == vremeTermina);

            ViewBag.CurrentFilterLekar = searchLekar;
            ViewBag.CurrentFilterDatum = searchDatum;
            ViewBag.CurrentFilterVreme = searchVreme;

            ViewBag.LekarSortParm = sortOrder == "Lekar" ? "lekar_desc" : "Lekar";
            ViewBag.DatumSortParm = sortOrder == "Datum" ? "datum_desc" : "Datum";
            ViewBag.VremeSortParm = sortOrder == "Vreme" ? "vreme_desc" : "Vreme";

            switch (sortOrder)
            {
                case "Lekar":
                    termini = termini.OrderBy(t => t.LekarPodaci.Prezime).ThenBy(t => t.LekarPodaci.Ime);
                    break;
                case "lekar_desc":
                    termini = termini.OrderByDescending(t => t.LekarPodaci.Prezime).ThenByDescending(t => t.LekarPodaci.Ime);
                    break;
                case "Datum":
                    termini = termini.OrderBy(t => t.DatumTermina);
                    break;
                case "datum_desc":
                    termini = termini.OrderByDescending(t => t.DatumTermina);
                    break;
                case "Vreme":
                    termini = termini.OrderBy(t => t.DatumTermina.TimeOfDay);
                    break;
                case "vreme_desc":
                    termini = termini.OrderByDescending(t => t.DatumTermina.TimeOfDay);
                    break;
                default:
                    termini = termini.OrderBy(t => t.DatumTermina);
                    break;
            }

            return View(termini.ToList());
        }

        public ActionResult TerapijePage()
        {
            (bool autorizovan, string pacijent) = Autorizacija();

            if (!autorizovan)
                return RedirectToAction("Index", "Login");

            IEnumerable<Termin> termini = SkladistePodataka.Database.Termini.Where(x => x.Pacijent == pacijent && x.StatusTermina == StatusTermina.ZAUZET);

            // Povezivanje lekara sa terminom
            termini.ForEach(x =>
            {
                if (string.IsNullOrEmpty(x.Lekar))
                    x.LekarPodaci = new Lekar("/", "/", "/", "/", DateTime.Now, "/", new List<string>());
                else
                    x.LekarPodaci = SkladistePodataka.Database.Lekari.FirstOrDefault(l => l.KorisnickoIme == x.Lekar);
            });

            return View(termini);
        }

        [HttpPost]
        public ActionResult ReserveTermin(string terminId)
        {
            try
            {
                Session["pacijent_greska"] = null;
                List<Termin> termini = SkladistePodataka.Database.Termini;
                List<Pacijent> pacijenti = SkladistePodataka.Database.Pacijenti;
                List<ZdravstveniKarton> kartoni = SkladistePodataka.Database.ZdravstveniKartoni;

                (bool autorizovan, string pacijent) = Autorizacija();

                if (!autorizovan)
                    return RedirectToAction("Index", "Login");

                Termin termin = termini.FirstOrDefault(x => x.TerminID == terminId && x.StatusTermina == StatusTermina.SLOBODAN);
                Pacijent pacijentdb = pacijenti.FirstOrDefault(x => x.KorisnickoIme == pacijent);
                ZdravstveniKarton karton = kartoni.FirstOrDefault(x => x.Pacijent == pacijent);

                if(termin == null || pacijentdb == null)
                {
                    Session["pacijent_greska"] = "Nije moguce zauzeti odabrani termin!";
                    return RedirectToAction("Index");
                }
                else
                {
                    termin.Pacijent = pacijent;
                    termin.StatusTermina = StatusTermina.ZAUZET;

                    if (karton == null)
                        kartoni.Add(new ZdravstveniKarton(pacijent, new List<string>() { termin.TerminID }));
                    else
                        karton.Termini.Add(termin.TerminID);

                    pacijentdb.ZakazaniTermini.Add(termin.TerminID);
                    SkladistePodataka.AzuriranjePodataka();

                    return RedirectToAction("Index");
                }
            }
            catch
            {
                Session["pacijent_greska"] = "Nije moguce zauzeti odabrani termin!";
                return RedirectToAction("Index");
            }
        }



        public (bool, string) Autorizacija()
        {
            if (Session["korisnik"] is Sesija sesija && sesija.Uloga == Uloga.PACIJENT)
                return (true, sesija.KorisnickoIme);
            else
                return (false, null);
        }
    }
}
